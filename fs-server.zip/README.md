Fansub server
================
Debido a la repetida tarea de montar un servidor de cero en ArchLinux,
con exactamente las mismas aplicaciones/configuraciones, me ha
llevado a la necesidad de crear un meta-paquete, con la esperanza de serle útil
a más de alguno, como es de útil para mí.

Primeros pasos
==============
Suponiendo que has contrado un servidor en algún host. Y, montado ArchLinux
como sistema operativo. Como mínimo, tu host debió darte los siguientes datos
para acceder a él vía SSH:

  - ip del servidor
  - usuario (root, o con derechos de administración)
  - password del usuario

Si estás en Windows, necesitarás un cliente SSH, si tienes Win10 no necesitarás
instalar ningún cliente SSH debido a que windows trae por defecto
OpenSHH. De lo contrario, te tocará instalar un cliente ssh como putty [1], o
bien instalar openssh desde msys2 [2] con el comando `pacman -S openssh`

Una vez instalado el cliente ssh, abre su respectiva terminal. Y comprueba que
funcione

	$ ssh -v

Para ingresar al servidor basta ejecutar

	$ ssh <usuario>@<ip-server>

Se te solicitará la contraseña del usuario, además si es la primera vez que
te conectas te pedirá que agregues la firma del servidor.

Ya ingresado al servidor, deberás instalar los paquetes básicos de ArchLinux,
para esto, ejecuta:

	$ sudo pacman -Syy
	$ sudo pacman -S base base-devel git --needed --noconfirm

Eso es todo, ya tienes lo necesario para instalar el paquete.

Instalación
==============
Clona el repositorio.

	$ git clone https://github.com/EduenSarceno/fs-server.git

Compila el paquete e instala

	$ cd fs-server && makepkg -si

Reinicia el servidor

	$ sudo systemctl reboot

[1]: https://www.putty.org/
[2]: https://www.msys2.org/
